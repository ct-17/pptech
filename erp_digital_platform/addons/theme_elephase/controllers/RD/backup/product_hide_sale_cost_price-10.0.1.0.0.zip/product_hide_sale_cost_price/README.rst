Hide Product Cost Price and Sale Price
======================================
With Odoo <a href="https://github.com/kurniawanlucky/Odoo10.0">Hide Product Cost Price and Sale Price</a>,
You can Hide Product Cost Price and Sale Price.

This module works on Product.
If you have any questions then you can contact us via following email.
email: Kurniawanluckyy@gmail.com
Provided by: Lucky Kurniawan(Kurniawanluckyy@gmail.com)

Usage
=====

* Install the module Hide Cost Price and Sale Price of product

Credits
=======

Contributors
------------

* Lucky Kurniawan <kurniawanluckyy@gmail.com>

